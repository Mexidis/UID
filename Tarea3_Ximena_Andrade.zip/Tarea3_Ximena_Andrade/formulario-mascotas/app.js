/** --- Swiper --- **/
const swiper = new Swiper(".about-swiper", {
  loop: true, // Hace que el slider se repita en bucle infinito
  slidesPerView: 1, // Muestra solo 1 diapositiva a la vez
  spaceBetween: 20, // Espacio de 20px entre diapositivas
  pagination: {
    el: ".swiper-pagination", // Contenedor de la paginación
    clickable: true, // Permite navegar dando clic en los puntos
  },
  navigation: {
    nextEl: ".swiper-button-next", // Botón siguiente
    prevEl: ".swiper-button-prev", // Botón anterior
  },
});

/** --- Definimos las variables del formulario1 --- **/
const contactBtn = document.getElementById("submit"); // Botón de enviar formulario
const contactName = document.getElementById("name"); // Campo nombre
const contactEmail = document.getElementById("email"); // Campo email
const contactGender = document.getElementsByName("gender"); // Opciones de género (radio)
const contactFeeling = document.getElementsByName("feeling"); // Opciones de sentimientos (checkbox)
const contactDate = document.getElementById("date"); // Campo de fecha
const contactComment = document.getElementById("comment"); // Campo de comentarios

// Evento al presionar el botón de enviar formulario
contactBtn.addEventListener("click", (e) => {
  e.preventDefault(); // Evita que el formulario se envíe y recargue la página

  // Validación de nombre
  if (contactName.value.trim() === "") {
    alert("Please, enter your name");
    return;
  }

  // Validación de email
  const emailValue = contactEmail.value.trim();
  if (emailValue === "") {
    alert("Please, enter your email");
    return;
  } else if (!emailValue.includes("@")) {
    alert("Please, include @");
    return;
  }

  // Validación de género
  let genderSelect = "";
  contactGender.forEach((g) => {
    if (g.checked) genderSelect = g.value; // Guarda el valor seleccionado
  });
  if (genderSelect === "") {
    alert("Please, select an option");
    return;
  }

  // Validación de sentimientos (mínimo 1 seleccionado)
  let feelingSelect = [];
  contactFeeling.forEach((f) => {
    if (f.checked) feelingSelect.push(f.value); // Agrega al array los seleccionados
  });
  if (feelingSelect.length === 0) {
    alert("Please, select minimum an option");
    return;
  }

  // Validación de fecha
  if (contactDate.value === "") {
    alert("Please, select a date");
    return;
  }

  // Validación de comentario
  if (contactComment.value.trim() === "") {
    alert("Please, enter your comment");
    return;
  }

  // Si todo está correcto, imprime en consola los valores
  console.log("Name:", contactName.value);
  console.log("Email:", contactEmail.value);
  console.log("Gender:", genderSelect);
  console.log("Feeling:", feelingSelect.join(", "));
  console.log("Date:", contactDate.value);
  console.log("Comment:", contactComment.value);
});

/** --- Definimos las constantes del segundo formulario para crear cartas --- **/
const petBtn = document.getElementById("mandar"); // Botón enviar mascotas
const petName = document.getElementById("petName"); // Campo nombre de mascota
const petAge = document.getElementById("age"); // Campo edad de mascota
const petType = document.getElementById("tipo"); // Campo especie/tipo
const petVacuna = document.getElementsByName("option"); // Opciones de vacunado (radio)
const petComment = document.getElementById("descripcion"); // Descripción de mascota

const tarjetasContainer = document.getElementById("tarjetasContainer"); // Contenedor de tarjetas creadas
const contadorTexto = document.getElementById("contador") || document.createElement("p"); // Texto contador

let contador = 0; // Contador inicial de tarjetas creadas

// Imágenes aleatorias que se asignan a las tarjetas puse poquitas xd
const imagenesRandom = [
  "https://i.pinimg.com/736x/b4/c4/6a/b4c46a4eb55a1e53c2e52fa3fcd744ce.jpg",
  "https://i.pinimg.com/736x/1f/3e/53/1f3e53ad8c9c9a3568d5e132b0663cde.jpg",
  "https://i.pinimg.com/736x/5d/13/7f/5d137f0ff64f0842c1ed5c4fe2ba2119.jpg",
  "https://i.pinimg.com/1200x/90/4a/ba/904abab3db0629515baef918f59efc05.jpg",
  "https://i.pinimg.com/736x/bb/4c/4b/bb4c4bd492b6a95405350fbb418f4d5d.jpg",
  "https://i.pinimg.com/1200x/09/b1/e8/09b1e82e29d778724c694fac7c09a893.jpg",
];

// Evento al presionar el botón de enviar mascota
petBtn.addEventListener("click", (e) => {
  e.preventDefault(); // Evita que el formulario se envíe

  // Obtiene los valores de los inputs
  const nombre = petName.value.trim();
  const edad = petAge.value.trim();
  const especie = petType.value.trim();
  const descripcion = petComment.value.trim();

  // Revisa cuál opción de vacunado fue seleccionada
  let vacunado = "";
  [...petVacuna].forEach((v) => {
    if (v.checked) vacunado = v.value;
  });

  // Validaciones: todos los campos obligatorios
  if (!nombre || !edad || !especie || !vacunado || !descripcion) {
    alert("Por favor, completa todos los campos.");
    return;
  }

  // Muestra los datos en consola
  console.log("Nombre:", nombre);
  console.log("Edad:", edad);
  console.log("Especie:", especie);
  console.log("Vacunado:", vacunado);
  console.log("Descripción:", descripcion);

  // Selecciona una imagen aleatoria del array
  let imagenURL = imagenesRandom[Math.floor(Math.random() * imagenesRandom.length)];

  // Crear tarjeta con la información de la mascota
  const tarjeta = document.createElement("div");
  tarjeta.classList.add("tarjeta");
  tarjeta.innerHTML = `
        <button class="btn-eliminar">X</button>
        <img src="${imagenURL}" alt="Mascota" class="tarjeta-img">
        <h3>${nombre}</h3>
        <p><strong><span>Edad:</span></strong> ${edad} año(s)</p>
        <p><strong><span>Especie:</span></strong> ${especie}</p>
        <p><strong><span>Vacunado:</span></strong> ${vacunado}</p>
        <p><strong><span>Descripción:</span></strong> ${descripcion}</p>
    `;

  // Evento del botón eliminar dentro de la tarjeta
  tarjeta.querySelector(".btn-eliminar").addEventListener("click", () => {
    const seguro = confirm("¿Seguro que quieres eliminar esta tarjeta?"); // Confirmación
    if (seguro) {
      tarjeta.remove(); // Elimina la tarjeta
      contador = tarjetasContainer.children.length; // Recalcula el número de tarjetas
      contadorTexto.textContent = `Mascotas registradas: ${contador}`;
      contadorTexto.classList.add("title-mascotas");
    }
  });

  // Agregar tarjeta al contenedor
  tarjetasContainer.appendChild(tarjeta);

  // Actualizar contador
  contador++;
  contadorTexto.textContent = `Mascotas registradas: ${contador}`;
  contadorTexto.classList.add("title-mascotas");

  // Limpiar los campos del formulario
  petName.value = "";
  petAge.value = "";
  petType.value = "";
  petComment.value = "";
  [...petVacuna].forEach((v) => (v.checked = false)); // Desmarca los radios
});
